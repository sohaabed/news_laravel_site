<img  src="{{asset('home/img/logo.png')}} "  style="width:197.2px !important" {{ $attributes }}>
    
</img>
