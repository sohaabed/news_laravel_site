<?php
symlink(__DIR__.'/../storage/app/public',__DIR__.'/storage');