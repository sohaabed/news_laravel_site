﻿<?php if (isset($component)) { $__componentOriginal7f8bd67401d08bbe95ee382a99ebfbb1a8287678 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserPanelComponent::class, []); ?>
<?php $component->withName('user-panel-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<section class="content" style="    margin: 70px 100px 0 100px !important;">
        <div class="container-fluid" >
            <div class="block-header">
            <h1  style="color:red;opacity: 80%;">
                               NEWS
                            </h1>
            </div>
            <!-- Basic Validation -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header" style="background:red; color:white;opacity: 80%;" >
                            <h2 style="color:white">
                               Add new
                            </h2>
                        </div>
                        <div class="body">
                            <form id="form_validation" method="post" action="<?php echo e(route('user.content.store')); ?>" enctype="multipart/form-data" >
                               <?php echo csrf_field(); ?>
   <?php echo $__env->make('user.content._form',[
    
    'submit_button'=>'Add'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php if (isset($__componentOriginal7f8bd67401d08bbe95ee382a99ebfbb1a8287678)): ?>
<?php $component = $__componentOriginal7f8bd67401d08bbe95ee382a99ebfbb1a8287678; ?>
<?php unset($__componentOriginal7f8bd67401d08bbe95ee382a99ebfbb1a8287678); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\news\resources\views/user/content/create.blade.php ENDPATH**/ ?>