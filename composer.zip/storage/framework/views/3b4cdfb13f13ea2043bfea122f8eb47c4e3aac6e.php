

<div class="form-group ">

    <div class="form-line <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> focused error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
    <input type="text" class="form-control" name="short_description" required  <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-invalid="true" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="<?php echo e(old('short_description',$content->short_description)); ?>" >
        <label class="form-label">Short Description</label>
    </div>
    <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="d-block" style="color:red;margin:top 20px;"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>


<div class="form-group">

        <select  name="category" class="selectpicker"  >
            <option value="">Select Category</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>" <?php if(old('category',$content->category_id)==$category->id): ?> selected <?php endif; ?> ><?php echo e($category->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="d-block" style="color:red"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <style>
        button.btn.dropdown-toggle{
           width: 1248px !important;
           height: 40px !important;
           
       }
       .filter-option-inner-inner,span.text {
    font-size: large !important;
}
.form-group{
    margin-top: 30px;
}

       </style>
   

 




    <div class="form-group">
    <textarea id="summernote" name="new_content">
        <?php echo e(old('new_content',$content->new_content)); ?>

    </textarea>
    </div>
    <?php $__errorArgs = ['new_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="d-block" style="color:red"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


<div class="form-group">
<label class="form-label" style="display: block;">Basic Image:</label>
   <input type="file" name="image" value="<?php echo e(old('image',$content->image)); ?>"   > 
  <img src="<?php echo e($content->image_url); ?>" alt="<?php echo e($content->image_url); ?>" width="100px" height="120px" style="margin:20px">

    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="d-block" style="color:red"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="form-group">
<label class="form-label" style="display: block;">Images:</label>
   <input type="file" name="images[]" multiple  > 
   <?php if($content->images): ?>
   <?php $__currentLoopData = $content->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
   <img class=img src="<?php echo e($image->image_url); ?>" alt="" width="100px" height="120px" style="margin:20px;">
 <a href=""  class="del_photo"> <i  ></i></a>
   

  
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
</div>



<div class="clearfix"></div>
<button class="btn btn-danger waves-effect" type="submit"><?php echo e($submit_button); ?></button>
</form>
</div>
</div>
</div>
</div>
<!-- #END# Basic Validation -->

</div>
</section><?php /**PATH C:\xampp\htdocs\news\resources\views/user/content/_form.blade.php ENDPATH**/ ?>