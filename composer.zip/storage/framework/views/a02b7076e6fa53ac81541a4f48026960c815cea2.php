<?php if (isset($component)) { $__componentOriginale46e501e9d5ec3e706142537fc3f903a6f33381b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HomeComponent::class, []); ?>
<?php $component->withName('home-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <!-- Breadcrumb Start -->
    <div class="breadcrumb-wrap">
        <div class="container">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">News</a></li>
                <li class="breadcrumb-item active">News details</li>
            </ul>
        </div>
    </div>
    <!-- Breadcrumb End -->

    <!-- Single News Start-->
    <div class="single-news">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="sn-container">
                        <div class="sn-img">
                            <img src="<?php echo e($content->image_url); ?>" />
                        </div>
                        <div class="sn-content">
                            <h1 class="sn-title"><?php echo e($content->short_description); ?></h1>

                            <?php echo $content->new_content; ?>


                            <?php if($content->images!=null): ?>
                            <?php $__currentLoopData = $content->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <img style="margin-bottom: 10px !important;" src="<?php echo e($image->image_url); ?>" width="750">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="sn-related">
                        <h2>Related News</h2>
                        <div class="row sn-slider">

                            <?php $__currentLoopData = $category->contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="sn-img">
                                    <img src="<?php echo e($cont->image_url); ?>" />
                                    <div class="sn-title">
                                        <a href="<?php echo e(route('home.show',$cont->id)); ?>"> <?php echo e($cont->short_description); ?> </a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="sidebar">
                        <div class="sidebar-widget">
                            <h2 class="sw-title">In This Category</h2>
                            <div class="news-list">
                                <?php $__currentLoopData = $category->contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="nl-item">
                                    <div class="nl-img">
                                        <img src="<?php echo e($cont->image_url); ?>" />
                                    </div>
                                    <div class="nl-title">
                                        <a href="<?php echo e(route('home.show',$cont->id)); ?>"><?php echo e($cont->short_description); ?></a>
                                    </div>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>



                        <div class="sidebar-widget">
                            <div class="tab-news">
                                <ul class="nav nav-pills nav-justified">
                                <li class="nav-item">
                                <a class="nav-link active" data-toggle="pill" href="#popular">Popular</a>
                            </li>
                                    <li class="nav-item">
                                        <a class="nav-link" data-toggle="pill" href="#latest">Latest</a>
                                    </li>
                                </ul>

                                <div class="tab-content">

                                    <div id="popular" class="container tab-pane active">
                                        <?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="tn-news">
                                            <div class="tn-img">
                                                <img src="<?php echo e($pop->image_url); ?>" />
                                            </div>
                                            <div class="tn-title">
                                                <a href="<?php echo e(route('home.show',$pop->id)); ?>"><?php echo e($pop->short_description); ?></a>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>


                                        <div id="latest" class="container tab-pane fade">
                                            <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tn-news">
                                                <div class="tn-img">
                                                    <img src="<?php echo e($lat->image_url); ?>" />
                                                </div>
                                                <div class="tn-title">
                                                    <a href="<?php echo e(route('home.show',$lat->id)); ?>"><?php echo e($lat->short_description); ?></a>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>



                        <div class="sidebar-widget">
                            <h2 class="sw-title">News Category</h2>
                            <div class="category">
                                <ul>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('home')); ?>/#<?php echo e($category->title); ?>"><?php echo e($category->title); ?></a><span><?php echo e($category->visitor); ?></span></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>




                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Single News End-->

 <?php if (isset($__componentOriginale46e501e9d5ec3e706142537fc3f903a6f33381b)): ?>
<?php $component = $__componentOriginale46e501e9d5ec3e706142537fc3f903a6f33381b; ?>
<?php unset($__componentOriginale46e501e9d5ec3e706142537fc3f903a6f33381b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\news\resources\views/single-page.blade.php ENDPATH**/ ?>