<img  src="<?php echo e(asset('home/img/logo.png')); ?> "  style="width:197.2px !important" <?php echo e($attributes); ?>>
    
</img>
<?php /**PATH C:\xampp\htdocs\news\resources\views/components/application-logo.blade.php ENDPATH**/ ?>