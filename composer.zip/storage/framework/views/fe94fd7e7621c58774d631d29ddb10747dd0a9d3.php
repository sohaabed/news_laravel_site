﻿

<?php if (isset($component)) { $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PanelLayout::class, []); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">

            </div>
            <!-- Basic Examples -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">

                            <h1 style="color:red;opacity: 80%;">
                                CATEGOTY TABLE
                            </h1>

                        </div>
                        <div class="body">


                            <div>

                                <form class="row">
                                <div class="col-lg-3"> <a href="<?php echo e(route('admin.category.create')); ?>" class="add btn btn-info font-bold " style="font-size:large;opacity: 70%;">Add category  <span class=" material-icons font-bold " style="font-size:x-large;top:3px">add</span> </a></div>
                                    <div class="col-lg-5"></div>
                                    <div class="col-lg-3" style="padding:0px;"><input class="form-control "  type="search" name ="search" placeholder="Search" aria-label="Search" ></div>
                                    <div class="col-lg-1" style="padding: 3px 3px 0px 10px;"> <button class="search btn btn-danger" style="margin: 0px;opacity: 70%;" type="submit">Search</button></div>
                                </form>
                            </div>
                            <?php if(session()->has('success')): ?> 
      <div class=" alert alert-success" style="opacity: 70%;">
        <?php echo e(session()->get('success')); ?> 
      </div>
     <?php endif; ?> 

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                    <thead>
                                        <tr style="background:red; color:white;opacity: 80%;">
                
                                            <th>Title</th>
                                            <th>Description</th>
                                            <th>Status</th>
                                            <th>Readers</th>
                                            <th>Total news</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr style="background:red; color:white;opacity: 80%;">
                                            
                                            <th>Title</th>
                                            <th>Description</th>
                                            <th>Status</th>
                                            <th>Readers</th>
                                            <th>Total news</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td><?php echo e($category->title); ?></td>
                                            <td><?php echo e($category->description); ?></td>
                                            <td><span <?php if($category->status=="active"): ?> class="btn btn-success" <?php else: ?> class="btn btn-danger "<?php endif; ?>> <?php echo e($category->status); ?></span></td>
                                            <td><?php echo e($category->visitor); ?></td>
                                            <td><?php echo e($category->total_news); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.category.edit',$category->id)); ?>"><span class="material-icons btn btn-primary " style=" margin-right: 20px; font-size: large;opacity: 80%">mode_edit</span></a>
                                               <form action="<?php echo e(route('admin.category.delete',$category->id)); ?>" method="post" style="display: inline;" >
                                                  <?php echo csrf_field(); ?> 
                                                  <?php echo method_field('delete'); ?>
                                                <button type="submit" id="delete" class=" btn btn-danger" style="opacity: 80%"> <span class="material-icons " style="font-size: 20px;top:2px;opacity: 80%">delete</span>
                                                </button>   
                                            </form>
                                            </td>

                                        </tr>
                                        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                            <div class="container " style=" margin-bottom:10px">

<a href="<?php echo e(route('home')); ?>" style="color:red"> Go to the website<span class="material-icons">trending_flat</span></a>

</div>
</span></span></a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Examples -->

        </div>
    </section>

 <?php if (isset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937)): ?>
<?php $component = $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937; ?>
<?php unset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\news\resources\views/admin/category/index.blade.php ENDPATH**/ ?>