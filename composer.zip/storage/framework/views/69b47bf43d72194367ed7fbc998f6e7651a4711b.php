<?php if (isset($component)) { $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PanelLayout::class, []); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="block-header" style="margin-top: 0px;">
                <h1 style="color: red;opacity:70%;">Notification</h1>
            </div>


            <!-- Basic Examples -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">



                        </div>
                        <div class="body">




                            <div class="table-responsive" style="margin-top: 30px;">
                                <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                    <thead>

                                        <tr style="background:red; color:white;opacity: 80%;text-align: center;">
                                            <th></th>
                                            <th>Notification</th>
                                            <th>From</th>
                                            <th>To Category </th>

                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <?php if($notification->read()==true): ?> <?php else: ?> <?php endif; ?>
                                            <td style="width: 50px;" > <i class="material-icons" <?php if($notification->read()!==true): ?> style="color:red;opacity: 80%;" <?php endif; ?>>notifications</i></td>
                                            
                                                <td > <a href="<?php echo e($notification->data['action']); ?>" style="opacity:80%;color:black"><?php echo e($notification->data['body']); ?>  </a></td>
                                           
                                            <td ><?php echo e($notification->data['auther']); ?></td>
                                            <td ><?php echo e($notification->data['category']); ?> </td>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>



                            <div class="container " style=" margin-bottom:10px">

                                <a href="<?php echo e(route('admin.home.')); ?>" style="color:red"> Go to admin panel<span class="material-icons">trending_flat</span></a>

                            </div>
                        </div>


                    </div>

                </div>


            </div>
            <!-- #END# Basic Examples -->

        </div>

    </section>
 <?php if (isset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937)): ?>
<?php $component = $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937; ?>
<?php unset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\news\resources\views/admin/notification.blade.php ENDPATH**/ ?>