<div class="form-group form-float">
    <div class="form-line <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> focused error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
        <input type="text" class="form-control" name="title" required  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> aria-invalid="true" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="<?php echo e(old('title',$category->title)); ?>" >
        <label class="form-label">Title</label>
    </div>
    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="d-block" style="color:red"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>




<div class="form-group form-float">
    <div class="form-line <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> focused error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
        <textarea name="description" cols="30" rows="5" class="form-control" required >
        <?php echo e(old('description',$category->description)); ?>

        </textarea>
        <label class="form-label">Description</label>
    </div>
   
</div>
<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class=" d-block" style="color:red"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<div class="form-group">
    <input type="radio" name="status" id="active" class="with-gap"value='active' <?php if(old('status',$category->status)=='active'): ?> 	checked <?php endif; ?>   >
    <label for="active"> Active</label>

    <input type="radio" name="status" id="inactive" class="with-gap" value="inactive" <?php if(old('status',$category->status)=='inactive'): ?> 	checked <?php endif; ?> >
    <label for="inactive" class="m-l-20">Inactive</label>

    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="d-block" style="color:red"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<button class="btn btn-danger waves-effect" type="submit"><?php echo e($submit_button); ?></button>
</form>
</div>
</div>
</div>
</div>
<!-- #END# Basic Validation -->

</div>
</section><?php /**PATH C:\xampp\htdocs\news\resources\views/admin/category/_form.blade.php ENDPATH**/ ?>