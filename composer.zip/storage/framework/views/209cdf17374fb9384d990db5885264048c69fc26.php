<?php if (isset($component)) { $__componentOriginale46e501e9d5ec3e706142537fc3f903a6f33381b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HomeComponent::class, []); ?>
<?php $component->withName('home-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <!-- Top News Start-->
        <div class="top-news">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 tn-left">
                        <div class="row tn-slider">
                          <?php $__currentLoopData = $important; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $import): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="tn-img">
                                    <img src="<?php echo e($import->image_url); ?>"  height="344px" width="540px"/>
                                    <div class="tn-title">
                                        <a  href="<?php echo e(route('home.show',$import->id)); ?>"><?php echo e($import->short_description); ?></a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="col-md-6 tn-right">
                        <div class="row">
                            <?php $__currentLoopData = $tops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="tn-img">
                                    <img src="<?php echo e($top->image_url); ?>" height="172px" width="270" />
                                    <div class="tn-title">
                                        <a href="<?php echo e(route('home.show',$top->id)); ?>"><?php echo e($top->short_description); ?></a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Top News End-->

        <!-- Category News Start-->
        <div class="cat-news">
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                    <div class="col-md-6" id="<?php echo e($category->title); ?>">
                        <h2><?php echo e($category->title); ?></h2>
                        <div class="row cn-slider">

                            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($content->category_id==$category->id): ?>
                            <div class="col-md-6">
                                <div class="cn-img">
                                    <img src="<?php echo e($content->image_url); ?>" height="223px" width="285px" />
                                    <div class="cn-title">
                                        <a href="<?php echo e(route('home.show',$content->id)); ?>"><?php echo e($content->short_description); ?></a>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                    
                </div>
            </div>
        </div>
        <!-- Category News End-->
        
        <!-- Tab News Start-->
        <div class="tab-news">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <ul class="nav nav-pills nav-justified">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="pill" href="#featured">Featured News</a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="pill" href="#latest">Latest News</a>
                            </li>
                        </ul>

                        <div class="tab-content">
                            <div id="featured" class="container tab-pane active">
                                <?php $__currentLoopData = $important_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $important): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tn-news">
                                    <div class="tn-img">
                                        <img src="<?php echo e($important->image_url); ?>" />
                                    </div>
                                    <div class="tn-title">
                                        <a href=" <?php echo e(route('home.show',$important->id)); ?> "><?php echo e($important->short_description); ?></a>
                                    </div>
                                </div>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                                
                               
                            <div id="latest" class="container tab-pane fade">
                            <?php $__currentLoopData = $most_recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                            <div class="tn-news">
                                    <div class="tn-img">
                                        <img src="<?php echo e($recent->image_url); ?>" />
                                    </div>
                                    <div class="tn-title">
                                        <a href="<?php echo e(route('home.show',$recent->id)); ?>"><?php echo e($recent->short_description); ?></a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <ul class="nav nav-pills nav-justified">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="pill" href="#m-viewed">Most Viewed</a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="pill" href="#m-recent">Most Recent</a>
                            </li>
                        </ul>

                        <div class="tab-content">
                            <div id="m-viewed" class="container tab-pane active">
                                <?php $__currentLoopData = $most_viewed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viewed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tn-news">
                                    <div class="tn-img">
                                        <img src="<?php echo e($viewed->image_url); ?>" />
                                    </div>
                                    <div class="tn-title">
                                        <a href="<?php echo e(route('home.show',$viewed->id)); ?>"><?php echo e($viewed->short_description); ?></a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                            
                            <div id="m-recent" class="container tab-pane fade">
                            <?php $__currentLoopData = $most_recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                            <div class="tn-news">
                                    <div class="tn-img">
                                        <img src="<?php echo e($recent->image_url); ?>" />
                                    </div>
                                    <div class="tn-title">
                                        <a href="<?php echo e(route('home.show',$recent->id)); ?>"><?php echo e($recent->short_description); ?></a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Tab News Start-->

        <!-- Main News Start-->
        <div class="main-news">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9">
                        <div class="row">
                            <?php $__currentLoopData = $acontents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                            <div class="col-md-4">
                                <div class="mn-img">
                                    <img src="<?php echo e($content->image_url); ?>"  style="height: 143.44px;"/>
                                    <div class="mn-title">
                                        <a href="<?php echo e(route('home.show',$content->id)); ?>"><?php echo e($content->short_description); ?></a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </div>
                    </div>

                    <div class="col-lg-3" id="read">
                        <div class="mn-list">
                            <h2>Read More</h2>
                            <ul>
                            <?php $__currentLoopData = $acontents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('home.show',$content->id)); ?>"><?php echo e($content->short_description); ?></a></li>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Main News End-->

         <?php if (isset($__componentOriginale46e501e9d5ec3e706142537fc3f903a6f33381b)): ?>
<?php $component = $__componentOriginale46e501e9d5ec3e706142537fc3f903a6f33381b; ?>
<?php unset($__componentOriginale46e501e9d5ec3e706142537fc3f903a6f33381b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\news\resources\views/index.blade.php ENDPATH**/ ?>